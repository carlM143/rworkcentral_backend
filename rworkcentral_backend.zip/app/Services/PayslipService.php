<?php

namespace App\Services;

use App\Models\Company;
use App\Models\Payroll;
use App\Models\PayrollPeriod;

/**
 * Builds payslip data from a payroll record.
 * Used by Admin › Payslips and by the employee's own payslip page, so both show the same thing.
 */
class PayslipService
{
    public function payslipNo(Payroll $payroll, PayrollPeriod $period): string
    {
        $date = ($period->pay_period_start ?? $period->cutoff_end)->format('Ym');

        return sprintf('PS-%s-%d-%05d', $date, (int) $period->cutoff_number, $payroll->id);
    }

    public function periodData(PayrollPeriod $period): array
    {
        return [
            'id' => $period->id,
            'period_name' => $period->period_name,
            'cutoff_number' => (int) $period->cutoff_number,
            'pay_period_start' => $period->pay_period_start?->format('Y-m-d'),
            'pay_period_end' => $period->pay_period_end?->format('Y-m-d'),
            'cutoff_start' => $period->cutoff_start?->format('Y-m-d'),
            'cutoff_end' => $period->cutoff_end?->format('Y-m-d'),
            'payment_date' => $period->payment_date?->format('Y-m-d'),
            'status' => $period->status,
        ];
    }

    /** Full payslip: earnings, time deductions, contributions, loans, totals and bank. */
    public function detail(Payroll $payroll, PayrollPeriod $period): array
    {
        $payroll->loadMissing([
            'employee:id,emp_id,firstname,lastname,department_id',
            'employee.department',
            'payrollGroup:id,group_name,frequency',
            'salaryType:id,type_name',
            'contributions.contributionType:id,contribution_code,contribution_name',
        ]);

        $company = Company::query()->find($period->company_id);
        $breakdown = $payroll->breakdown ?? [];
        $rateType = $breakdown['rate_type'] ?? 'monthly';

        // Earnings
        $basicNote = match ($rateType) {
            'daily' => "{$payroll->days_worked} day(s) × ₱" . number_format((float) $payroll->daily_rate, 2),
            'hourly' => $this->minutesLabel((int) $payroll->worked_minutes) . ' worked',
            default => 'Semi-monthly rate',
        };

        // allowance_pay = main allowance + additional allowances; list them separately
        $additionalAllowances = collect($breakdown['additional_allowances'] ?? [])
            ->filter(fn ($line) => (float) ($line['amount'] ?? 0) > 0);

        $baseAllowance = round((float) $payroll->allowance_pay - $additionalAllowances->sum('amount'), 2);

        $earnings = array_values(array_filter([
            ['label' => 'Basic Pay', 'note' => $basicNote, 'amount' => (float) $payroll->basic_pay],
            $baseAllowance > 0
                ? ['label' => 'Allowance', 'note' => null, 'amount' => $baseAllowance]
                : null,
            ...$additionalAllowances->map(fn ($line) => [
                'label' => $line['allowance_name'] ?? 'Allowance',
                'note' => 'Additional allowance',
                'amount' => (float) $line['amount'],
            ])->all(),
            (float) $payroll->overtime_pay > 0
                ? ['label' => 'Overtime', 'note' => $this->minutesLabel((int) $payroll->overtime_minutes), 'amount' => (float) $payroll->overtime_pay]
                : null,
            (float) $payroll->holiday_pay > 0
                ? [
                    'label' => 'Holiday Pay',
                    'note' => $this->holidayNote($breakdown['holidays'] ?? [], 'holiday_date'),
                    'amount' => (float) $payroll->holiday_pay,
                ]
                : null,
        ]));

        // Holidays the employee was not paid for (monthly salary is reduced for these)
        $unpaidHolidays = collect($breakdown['holiday_days'] ?? [])
            ->filter(fn ($d) => empty($d['worked']) && empty($d['paid']) && empty($d['rest_day']))
            ->all();

        // Day count: days worked + holidays paid without working
        $paidHolidayDays = collect($breakdown['holiday_days'] ?? [])
            ->filter(fn ($d) => empty($d['worked']) && !empty($d['paid']))
            ->count();

        $daysWorked = (float) $payroll->days_worked;

        $days = [
            'worked' => $daysWorked,
            'paid_holidays' => $paidHolidayDays,
            'unpaid_leave' => (float) $payroll->unpaid_leave_days,
            'total_paid' => $daysWorked + $paidHolidayDays,
        ];

        // Less: time not worked
        $timeDeductions = array_values(array_filter([
            (float) $payroll->late_deduction > 0
                ? ['label' => 'Late', 'note' => $this->minutesLabel((int) $payroll->late_minutes), 'amount' => (float) $payroll->late_deduction]
                : null,
            (float) $payroll->undertime_deduction > 0
                ? ['label' => 'Undertime', 'note' => $this->minutesLabel((int) $payroll->undertime_minutes), 'amount' => (float) $payroll->undertime_deduction]
                : null,
            (float) $payroll->unpaid_leave_deduction > 0
                ? ['label' => 'Unpaid Leave', 'note' => (float) $payroll->unpaid_leave_days . ' day(s)', 'amount' => (float) $payroll->unpaid_leave_deduction]
                : null,
            (float) $payroll->unpaid_holiday_deduction > 0
                ? [
                    'label' => 'Unpaid Holiday',
                    'note' => $this->holidayNote($unpaidHolidays, 'date'),
                    'amount' => (float) $payroll->unpaid_holiday_deduction,
                ]
                : null,
        ]));

        // Deductions from gross pay
        $deductions = [];

        foreach ($payroll->contributions as $c) {
            $deductions[] = [
                'label' => $c->contributionType?->contribution_name ?? 'Contribution',
                'note' => null,
                'amount' => (float) $c->employee_share,
            ];
        }

        $deductions[] = [
            'label' => 'Withholding Tax',
            'note' => null,
            'amount' => (float) $payroll->withholding_tax,
        ];

        foreach ($breakdown['loans'] ?? [] as $loan) {
            $deductions[] = [
                'label' => $loan['loan_type'] ?? 'Loan',
                'note' => trim(($loan['reference'] ?? '') . ' · balance ₱' . number_format((float) ($loan['balance_after'] ?? 0), 2), ' ·'),
                'amount' => (float) $loan['amount'],
            ];
        }

        // Paid by the company (for information)
        $employerShares = $payroll->contributions->map(fn ($c) => [
            'label' => $c->contributionType?->contribution_name ?? 'Contribution',
            'note' => (float) $c->employer_ec_amount > 0
                ? 'incl. EC ₱' . number_format((float) $c->employer_ec_amount, 2)
                : null,
            'amount' => round((float) $c->employer_share + (float) $c->employer_ec_amount, 2),
        ])->values();

        return [
            'payslip_no' => $this->payslipNo($payroll, $period),
            'company' => [
                'name' => $company?->company_name ?? 'Company',
                'address' => $company?->address ?? null,
            ],
            'period' => $this->periodData($period),
            'employee' => [
                'emp_id' => $payroll->employee?->emp_id,
                'name' => $this->employeeName($payroll->employee),
                'department' => $payroll->employee?->department?->department_name,
                'payroll_group' => $payroll->payrollGroup?->group_name,
                'salary_type' => $payroll->salaryType?->type_name,
                'basic_salary' => (float) $payroll->basic_salary,
            ],
            'days' => $days,
            'earnings' => $earnings,
            'time_deductions' => $timeDeductions,
            'deductions' => $deductions,
            'employer_shares' => $employerShares,
            'totals' => [
                'earnings' => round(collect($earnings)->sum('amount'), 2),
                'time_deductions' => round(collect($timeDeductions)->sum('amount'), 2),
                'gross_pay' => (float) $payroll->gross_pay,
                'total_deductions' => (float) $payroll->total_deductions,
                'net_pay' => (float) $payroll->net_pay,
            ],
            'bank' => [
                'bank_name' => $payroll->bank_name ?: null,
                'account_name' => $payroll->account_name ?: null,
                'account_number' => $this->maskAccount($payroll->account_number),
            ],
            'finalized_at' => $payroll->finalized_at?->format('Y-m-d H:i'),
        ];
    }

    private function employeeName($employee): string
    {
        return $employee ? trim("{$employee->firstname} {$employee->lastname}") : 'Employee';
    }

    private function minutesLabel(int $minutes): string
    {
        $h = intdiv($minutes, 60);
        $m = $minutes % 60;

        return $h ? trim("{$h}h " . ($m ? "{$m}m" : '')) : "{$m}m";
    }

    private function maskAccount(?string $number): ?string
    {
        if (!$number) {
            return null;
        }

        return strlen($number) <= 4
            ? $number
            : str_repeat('•', strlen($number) - 4) . substr($number, -4);
    }

    /** "All Souls' Day (Nov 2), Rizal Day (Dec 30)" from holiday lines. */
    private function holidayNote(array $items, string $dateKey): ?string
    {
        $note = collect($items)
            ->map(fn ($h) => ($h['holiday_name'] ?? 'Holiday') . ' (' . date('M j', strtotime((string) $h[$dateKey])) . ')')
            ->unique()
            ->join(', ');

        return $note !== '' ? $note : null;
    }
}
